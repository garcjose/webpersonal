#include <iostream>
#include <fstream>
#include <sstream>
#include "IndiceNODENSO.hpp"
//macros que identifican a los nombres
//de archivo pasados por parametro
#define fileD argv[1]   //archivo de datos
#define fileIP argv[2]  //archivo de indice primario
#define fileIND argv[3] //archivo de indice no denso
#define fileB argv[4]   //archivo de bloques
#define fileTXT argv[5] //arhivo .txt de nuevo registros

int menu();                 //muestra el menu
void clear();               //limpia consola
void pause();               //pausa el programa
char* ltoa(long);           //transforma long a char*
void error(int,char* ="");  //informa de errores

int main(int argc,char **argv)
{
    int opcion,n;
    fstream ficheroTxt;
    int numRegs;
    int tamMaxReg=sizeof(BRIDGE)+NUMCAMPOS+BITBORRADO;//87
    int tamMaxIP=sizeof(INDICEP)+2;//14
    //primero lee el factor de carga de los bloques
    cout<<"\n\t----------------------------------------------"<<endl;
    cout<<"\tIntroduzca factor de carga para los bloques: ";
    cin>>n;
    int tamMaxBloque=n*tamMaxReg+3+n;//3 separador campos y n separadores registros|355
    char valor[50];//lo usaremos para leer de teclado
    long pos;
    bool yaInsert=false;
    do
    {
        //programa estara en un bucle infinito hasta que se introduzca 0
        clear();
        opcion = menu();//obtenemos opcion elegida
        switch (opcion)
        {
        case 0:
            clear();
            cout<<"�Gracias por usar el programa!"<<endl;
            pause();
            break;
        case 1:
        {
            //usamos el fichero de datos y el indicePrimario
            //para crear el arcihvo de bloques
            clear();
            cout<<"CREANDO ARCHIVO DE BLOQUES..."<<endl<<endl;
            ESFicheroBinario ESFileDatos(fileD,tamMaxReg,r);
            INDICE iP(fileIP,tamMaxIP,r,primario,POS_PRIMARIO);
            FileBloques fbloques(fileB,tamMaxBloque,w,n,tamMaxReg);
            if ((numRegs=fbloques.creaArchivoBloques(ESFileDatos,iP))==-1)error(1,fileB);
            cout<<"Se insertaron "<<numRegs/n<<" bloques."<<endl;
            cout<<"\n...ARCHIVO CREADO!"<<endl<<endl;
            fbloques.EscribirCabecera();//actualizamos cabecera fichero
            yaInsert=false;
            pause();
            break;
        }
        case 2:
        {
            //usamos el archivo de bloques para crear el indice no denso
            clear();
            cout<<"CREANDO ARCHIVO DE INDICE NO DENSO..."<<endl<<endl;
            FileBloques fbloques(fileB,tamMaxBloque,r,n,tamMaxReg);
            INDICEND i(fileIND,tamMaxIP,w,primario,POS_PRIMARIO);
            if ((numRegs=i.creaIndiceNoDenso(fbloques))==-1)error(0,fileIND);
            cout<<endl<<"Se insertaron "<<numRegs<<" registros"<<endl;
            i.EscribirCabecera();//actualizamos cabecera indice
            cout<<"\n...INDICE CREADO!"<<endl<<endl;
            pause();
            break;
        }
        case 3:
        {
            //mostramos el archivo de bloques con el metodo listarBloques()
            clear();
            cout<<"LISTADO DE BLOQUES DE ARCHIVO DE DATOS"<<endl<<endl;
            FileBloques fbloques(fileB,tamMaxBloque,r,n,tamMaxReg);
            if ((numRegs=fbloques.listarBloques())==-1)error(3,fileB);
            cout<<endl<<"Se mostraron "<<numRegs/n<<" bloques"<<endl<<endl;
            pause();
            break;
        }
        case 4:
        {
            //mostramos el archivo de indince con el metodo listarIndiceNoDenso()
            clear();
            cout<<"LISTADO DE REGISTROS DE ARCHIVO DE INDICE NO DENSO"<<endl<<endl;
            INDICEND i(fileIND,tamMaxIP,r,primario,POS_PRIMARIO);
            if ((numRegs=i.listarIndiceNoDenso())==-1)error(2,fileIND);
            cout<<endl<<"Se mostraron "<<numRegs<<" registros"<<endl<<endl;
            pause();
            break;
        }
        case 5:
        {
            //mostramos el listado ordenado del archivo de bloques
            clear();
            cout<<"LISTADO ORDENADO DE ARCHIVO BLOQUES"<<endl<<endl;
            FileBloques fbloques(fileB,tamMaxBloque,r,n,tamMaxReg);
            INDICEND i(fileIND,tamMaxIP,r,primario,POS_PRIMARIO);
            if ((numRegs=i.listarOrdenadoIPNoDenso(fbloques))==-1)error(4,fileIND);
            cout<<"Se mostraron "<<numRegs<<" bloques"<<endl<<endl;
            pause();
            break;
        }
        case 6:
        {
            //leemos la clave primaria a buscar obteniendo bloque en el que buscar
            //mediante la busqueda binaria, buscamos en bloque y si no se encuentra
            //en la zona de overflow
            clear();
            bool find=false;
            FileBloques fbloques(fileB,tamMaxBloque,r,n,tamMaxReg);
            INDICEND i(fileIND,tamMaxIP,r,primario,POS_PRIMARIO);
            BloqueIND b(tamMaxBloque);
            cout<<"Introduzca el valor de clave primaria a buscar: ";
            cin>>valor;
            pos=i.busquedaBinariaIPNoDenso(valor,false);
            if (pos==-1)error(6,valor);
            else
            {
                if (fbloques.LeerBloque(b,pos)==-1) error(5,ltoa(pos));
                cout<<"Buscando en bloque..."<<endl;
                if (!(find=b.buscar(valor)))error(8,valor);
                if (!find)
                {
                    cout<<"Buscando en zona overflow..."<<endl;
                    if (!fbloques.buscarRegZonaOverFlown(b,valor))error(9,valor);
                }
            }
            pause();
            break;
        }
        case 7:
        {
            //abrimos el archivo de texto para leer los registros nuevos
            //y mediante InsertarNuevosRegistros() de INDICEND
            //los insertamos haciendo uso del archivo de bloques
            clear();
            if (yaInsert){error(10);pause();break;}//evita insertar 2 veces los registros

            ficheroTxt.open(fileTXT,ios::in);
            if (ficheroTxt==NULL)error(7,fileTXT);

            FileBloques fbloques(fileB,tamMaxBloque,rw,n,tamMaxReg);
            INDICEND i(fileIND,tamMaxIP,rw,primario,POS_PRIMARIO);
            numRegs=i.InsertarNuevosRegistros(ficheroTxt,fbloques);
            cout<<"Se a�adieron "<<numRegs<<" registros e "<<" indices."<<endl<<endl;

            ficheroTxt.close();
            ficheroTxt.clear();
            fbloques.EscribirCabecera();//actualizamos cabecera
            yaInsert=true;
            pause();
            break;
        }
        default://si no se selecciona un valor valido
            clear();
            cout<<"Opcion incorrecta"<<endl;
            pause();
            break;
        }
    }
    while (opcion!=0);
}
int menu()
{
    //simulacion de menu del programa
    int opcion;
    cout<<"\n\t----------------------------------------------"<<endl;
    cout<<"\t--------------- PRACTICA 2b OGA --------------"<<endl;
    cout<<"\t--------- JOSE ANGEL GARCIA FERNANDEZ --------"<<endl;
    cout<<"\t----------------------------------------------"<<endl;
    cout<<"\t--> 1 -\tCrear Archivo Bloques"<<endl;
    cout<<"\t--> 2 -\tCrear Archivo Indice Primario No Denso"<<endl;
    cout<<"\t--> 3 -\tListar Archivo Bloques"<<endl;
    cout<<"\t--> 4 -\tListar Indice Primario No Denso"<<endl;
    cout<<"\t--> 5 -\tListar Ordenado Archivo Bloques"<<endl;
    cout<<"\t--> 6 -\tBusqueda en Archivo por Clave Primaria"<<endl;
    cout<<"\t--> 7 -\tInsertar registros en archivo de datos"<<endl;
    cout<<"\t--> 0 -\tSalir"<<endl;
    cout<<"\t----------------------------------------------"<<endl;
    cout<<"\t--> ";
    cin>>opcion;
    return opcion;
}
char* ltoa(long n)
{
    //usamos la clase stringstream
    //para transformar el long en char*
    // usando el const_cast
    stringstream ss;
    string aux;
    ss<<n;
    ss>>aux;
    return const_cast<char*>(aux.c_str());
}
//comentar o descomentar lineas para ejecutar el linux o en windows
void clear()
{
    //usamos system para realizar la llamada
    //al sistema que limpia la pantalla
    system("CLS");//windows
    //system("clear");//linux
}
void pause()
{
    //usamos system para realizar la llamada
    //al sistema que pausa la ejecucion
    system("pause");//windows
    //en linux no existe asi que usamos un bucle while
    //leyendo caracteres hasta que se introduzca el fin de linea
    //cout<<"Introduzca enter para continuar:"<<endl;//linux
    //while ( getchar() != '\n');
}
void error(int n,char* info)
{
    //en funcion del parametro n mostramos un error u otro anyadiendo
    //la informacion de la cadena de caracteres info
    switch (n)
    {
    case 0:
        cerr<<"Se produjo un error en la creacion del archivo de indice "<<info<<endl;
        break;
    case 1:
        cerr<<"Se produjo un error en la creacion del archivo de bloques  "<<info<<endl;
        break;
    case 2:
        cerr<<"Se produjo un error en el listado del archivo de indice "<<info<<endl;
        break;
    case 3:
        cerr<<"Se produjo un error en el listado del archivo de bloques "<<info<<endl;
        break;
    case 4:
        cerr<<"Se produjo un error en el listado ordenado del archivo de bloques en base al indice "<<info<<endl;
        break;
    case 5:
        cerr<<"Se produjo un error en la lectura de bloque con posicion abs "<<info<<endl;
        break;
    case 6:
        cerr<<"En la busqueda binaria no se encontro "<<info<<endl;
        break;
    case 7:
        cerr<<"Se produjo un error en la apertura del fichero de texto "<<info<<endl;
        break;
    case 8:
        cerr<<"No se encontro "<<info<<" en bloque"<<endl;
        break;
    case 9:
        cerr<<"No se encontro en zona overflown "<<info<<endl;
        break;
    case 10:
        cerr<<"Registros ya insertados"<<info<<endl;
        break;
    }
    if (n<2)//si no se ha cerado el indice o el archivo de bloques paramos ejecucion
        exit(-1);
}
