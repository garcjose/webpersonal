#include <iostream>
#include <fstream>
#define NUMCAMPOS 13
#define BITBORRADO 2*sizeof(char)
enum modoApertura {r,w,rw};
using namespace std;
typedef struct
{
    char Id[6];
    char River;
    int Location;
    int Erected;
    char Purpose[9];
    int Length;
    int Lanes;
    char ClearG;
    char TOrD[8];
    char Material[6];
    char Span[7];
    char Rel[4];
    char Type[9];
}BRIDGE;
typedef struct
{
    int numRegs;
    int tamMaxReg;
    long tope;
    //char fileDatos[15];
}CABECERA;
class ESRegistroBinario
{
protected:
    char *cadenaRegistro;
    int tamMaxRegistro;
public:
    ESRegistroBinario(int tamMax);
    ~ESRegistroBinario();
    char* GetCadenaRegistro()
    {
        return cadenaRegistro;
    }
    int GettamMaxRegistro()
    {
        return tamMaxRegistro;
    }
};
class Registro
{
public:
    BRIDGE Bridge;
public:
    //Obtiene el valor de la cadena para guardarla en el STRUCT.
    int ObtenerCadenaRegistro(char* cadenaRegistro);
    //Establece el valor de la cadena en base un a un STRUCT.
    void EstablecerCadenaRegistro(char* cadenaRegistro);
    //Muestra los campos del registro.
    void Mostrar();
    //Muestra los campos del registro en formato condensado
    friend ostream& operator<<(ostream&,const Registro&);
    //Sobrecarga operadores logicos
    bool operator>(const Registro &otro);
    bool operator<(const Registro &otro);
};
class ESFicheroBinario
{
public:
    ESRegistroBinario *ESRegBinario;
    CABECERA *cabecera; //Estructura con la informaci�n que se guarda al comienzo del fichero.
    int tamCabecera; //Tama�o de la cabecera.
    fstream fichero; //Fichero binario de registros.
    CABECERA *GetCabecera()
    {
        return cabecera;
    }
    int GetTamCabecera()
    {
        return tamCabecera;
    }
//Vac�a el contenido de una cadena
    void LimpiarCadena(char *cadena);
//M�todo constructor.
    ESFicheroBinario(char* nombreFichero, int tamMax,modoApertura mA);
//M�todo destructor.
    ~ESFicheroBinario();
//Obtiene la cabecera del fichero binario.
    void ObtenerCabecera();
//Escribe la cabecera al comienzo del fichero.
    void EscribirCabecera();
//Escribe en el fichero binario el contenido de cadenaRegistro.
    long EscribirCadenaRegistro();
//Lee del fichero binario un registro y lo guarda en cadenaRegistro.
    long LeerCadenaRegistro();
//Pasa una cadena con el formato del registro txt a una cadena que forma un registro binario.
    void FormatearCadenaRegistro(char *cadenaRegistroTxt);
//Lee el contenido de un registro del fichero txt y lo guarda en una cadena.
    int LeerRegistroTxt(fstream &ficheroTxt, char *cadenaRegistroTxt);
//Lee cada uno de los registros del txt y los inserta en el archivo binario
    int GenerarArchivoBinario(fstream &ficheroTxt);
//Lee un registro del archivo binario y lo guarda en un STRUCT.
    long LeerRegistro(Registro &registro);
    long LeerRegistro(Registro &registro, long pos);
//Busca un registro en base a un n�mero de campo y a su valor.
    long BuscarRegistro(int numCampo, char* valor);
//Obtiene un registro en base a su n�mero relativo.
    long ObtenerRegistro(int NRR);
//Elimina un registro marcandolo como no valido
    long EliminarRegistro(long pos);
//Inserta registros leidos desde un txt.
    long InsertarNuevosRegistros(fstream &ficheroTxt);
    //Inserta un registro en el archivo
    long InsertarRegistro(char *cadenaRegistroTxt);
//Muestra los registros del archivo binario.
    int ListarRegistros();
};
