#include "IndicesPS.h"

//Funciones para la ordenacion de los vectores de los indices:
int compareRegistrosIP(const void *a,const void *b)
{
    registroIP *regA=(registroIP*)a;
    registroIP *regB=(registroIP*)b;

    if (atoi(regA->indice.clavePrim+1)<atoi(regB->indice.clavePrim+1))
        return-1;
    else if (atoi(regA->indice.clavePrim+1)>atoi(regB->indice.clavePrim+1))
        return 1;
    return 0;
}

int compareRegistrosIS(const void *a,const void *b)
{
    registroIS *regA=(registroIS*)a;
    registroIS *regB=(registroIS*)b;

    if (strcmp(regA->indice.claveSec,regB->indice.claveSec)<0)
        return-1;
    else if (strcmp(regA->indice.claveSec,regB->indice.claveSec)>0)
        return 1;
    return 0;
}

INDICE::INDICE(char* nombreFichero,int tamMax,modoApertura mA,tipoIndice tipInd,int pos):ESFicheroBinario(nombreFichero,tamMax,mA)
{
    tI=tipInd;
    posClave=pos;
    modif=false;
}

INDICE::~INDICE()
{
}
int INDICE::creaIndice(ESFicheroBinario &ESFicBinarioReg)
{
    return tI==primario?creaIndicePrimario(ESFicBinarioReg):creaIndiceSecundario(ESFicBinarioReg);
}
int INDICE::creaIndicePrimario(ESFicheroBinario &ESFicBinarioReg)
{
    Registro registro;
    registroIP *vectorRegistrosIP=new registroIP[ESFicBinarioReg.cabecera->numRegs];
    int numIndices=0;
    long pos;

    while (!ESFicBinarioReg.fichero.eof())
    {
        pos=ESFicBinarioReg.LeerRegistro(registro);
        if (pos!=-1)
        {
            strcpy(vectorRegistrosIP[numIndices].indice.clavePrim,registro.Bridge.Id);
            vectorRegistrosIP[numIndices].indice.posicionReg=pos;
            numIndices++;
        }
    }
    //Ordenaci�n
    qsort(vectorRegistrosIP,numIndices,sizeof(INDICEP),compareRegistrosIP);
    for (int i=0;i<numIndices;i++)
    {
        cout<<vectorRegistrosIP[i]<<endl;
        vectorRegistrosIP[i].EstablecerCadenaRegistro(ESRegBinario->GetCadenaRegistro());
        if (EscribirCadenaRegistro()==-1)return -1;
    }

    cabecera->numRegs=numIndices;
    delete vectorRegistrosIP;
    return numIndices;
}
int INDICE::creaIndiceSecundario(ESFicheroBinario &ESFicBinarioReg)
{
    Registro registro;
    registroIS *vectorRegistrosIS=new registroIS[ESFicBinarioReg.cabecera->numRegs];
    int numIndices=0;
    long pos;

    while (!ESFicBinarioReg.fichero.eof())
    {
        pos=ESFicBinarioReg.LeerRegistro(registro);

        if (pos!=-1)
        {
            switch (posClave)
            {
            case 1:
                sprintf(vectorRegistrosIS[numIndices].indice.claveSec,"%c",registro.Bridge.River);
                break;
            case 2:
                sprintf(vectorRegistrosIS[numIndices].indice.claveSec,"%d",registro.Bridge.Location);
                break;
            case 3:
                sprintf(vectorRegistrosIS[numIndices].indice.claveSec,"%d",registro.Bridge.Erected);
                break;
            case 4:
                strcpy(vectorRegistrosIS[numIndices].indice.claveSec,registro.Bridge.Purpose);
                break;
            }
            strcpy(vectorRegistrosIS[numIndices].indice.clavePrim,registro.Bridge.Id);
            numIndices++;
        }
    }
    //Ordenaci�n
    qsort(vectorRegistrosIS,numIndices,sizeof(INDICES),compareRegistrosIS);
    for (int i=0;i<numIndices;i++)
    {
        cout<<vectorRegistrosIS[i]<<endl;
        vectorRegistrosIS[i].EstablecerCadenaRegistro(ESRegBinario->GetCadenaRegistro());
        if (EscribirCadenaRegistro()==-1)return -1;
    }
    cabecera->numRegs=numIndices;

    delete vectorRegistrosIS;
    return numIndices;
}

int INDICE::listarIndice()
{
    return tI==primario?listarIndicePrimario():listarIndiceSecundario();
}
int INDICE::listarIndicePrimario()
{
    registroIP regIndiceP;
    for (int i=0;i<cabecera->numRegs;i++)
    {
        if (LeerRegistroIP(regIndiceP)==-1)return -1;
        cout<<regIndiceP<<endl;
    }
    return cabecera->numRegs;
}
int INDICE::listarIndiceSecundario()
{
    registroIS regIndiceS;
    for (int i=0;i<cabecera->numRegs;i++)
    {
        if (LeerRegistroIS(regIndiceS)==-1)return -1;
        cout<<regIndiceS<<endl;
    }
    return cabecera->numRegs;
}
int INDICE::listarRegistrosOrdenado(ESFicheroBinario &ESFileDatos, char* iPrim)
{
    return tI==primario?listarRegistrosOrdenadoIP(ESFileDatos):listarRegistrosOrdenadoIS(ESFileDatos,iPrim);
}
int INDICE::listarRegistrosOrdenadoIP(ESFicheroBinario &ESFileDatos)
{
    registroIP regIP;
    Registro reg;
    int i;
    for (i=0;i<cabecera->numRegs;)
    {
        if (LeerRegistroIP(regIP)==-1)break;
        if (ESFileDatos.LeerRegistro(reg,regIP.indice.posicionReg)!=-1)
        {
            cout<<reg<<endl;
            i++;
        }
        else return -1;
    }
    return i;
}
int INDICE::listarRegistrosOrdenadoIS(ESFicheroBinario &ESFileDatos,char* iPrim)
{
    registroIS regIS;
    Registro reg;
    int i;
    long pos;
    INDICE i2(iPrim,sizeof(INDICEP)+2,r,primario,POS_PRIMARIO);
    for (i=0;i<cabecera->numRegs;)
    {
        if (LeerRegistroIS(regIS)==-1)break;
        pos=i2.busquedaBinariaIP(regIS.indice.clavePrim,false);
        if (pos!=-1)
            if (ESFileDatos.LeerRegistro(reg,pos)!=-1)
            {
                cout<<reg<<endl;
                i++;
            }
    }
    return i;
}

long INDICE::LeerRegistroIP(registroIP &regIndice1)
{
    long pos=LeerCadenaRegistro();
    if (pos==-1)return -1;
    regIndice1.ObtenerCadenaRegistro(ESRegBinario->GetCadenaRegistro());
    return pos;
}

long INDICE::LeerRegistroIS(registroIS &regIndice2)
{
    long pos=LeerCadenaRegistro();
    if (pos==-1)return -1;
    regIndice2.ObtenerCadenaRegistro(ESRegBinario->GetCadenaRegistro());
    return pos;
}
long INDICE::busquedaBinariaIP(char *clave,bool posEnIndice)
{
    int inf=0;
    int sup=cabecera->numRegs-1;
    int centro=0;
    registroIP regIP;
    while (inf<=sup)
    {
        centro=(inf+sup)/2;
        if (LeerRegistroIP(regIP,centro*cabecera->tamMaxReg+tamCabecera)==-1)return -1;
        if (regIP>clave)sup=centro-1;
        else if (regIP<clave)inf=centro+1;
        else return posEnIndice? centro*cabecera->tamMaxReg+tamCabecera:regIP.indice.posicionReg;
    }//devolvemos la posicion del registro en indice o la posicion del registro real de datos
    return -1;
}

long INDICE::LeerRegistroIP(registroIP &regIndice1,long pos)
{
    fichero.seekg(pos,ios::beg);
    return LeerRegistroIP(regIndice1);
}

long INDICE::LeerRegistroIS(registroIS &regIndice2,long pos)
{
    fichero.seekg(pos,ios::beg);
    return LeerRegistroIS(regIndice2);
}

int INDICE::busquedaBinariaIS(char *claveSec, INDICE &indiceFicPrimario, ESFicheroBinario &ESFileDatos)
{
    registroIS regIS;
    Registro reg;
    int inicio=0;
    int fin=cabecera->numRegs-1;
    int centro=0;
    bool encontrado=false;

    while (inicio<=fin && !encontrado)
    {
        centro=(inicio + fin)/2;
        if (LeerRegistroIS(regIS,centro*cabecera->tamMaxReg+tamCabecera)==-1)break;
        if (strcmp(claveSec,regIS.indice.claveSec)>0)
            inicio=centro+1;
        else if (strcmp(claveSec,regIS.indice.claveSec)<0)
            fin=centro-1;
        else
            encontrado=true;
    }

    if (encontrado)
    {
        vector<string> aux;//guardaremos las claves primarias de los registros validos
        long pos;
        int validos=0;
        int regCentral=centro;
        do
        {
            aux.push_back(regIS.indice.clavePrim);
            centro++;//comprobamos hacia abajo
            if (LeerRegistroIS(regIS,centro*cabecera->tamMaxReg+tamCabecera)==-1)break;
        }
        while (strcmp(regIS.indice.claveSec,claveSec)==0);
        if (fichero.eof())fichero.clear();//si hemos llegado a final de archivo reseteamos para mirar por abajo
        centro=regCentral;
        centro--;//comprobamos hacia arriba
        LeerRegistroIS(regIS,centro*cabecera->tamMaxReg+tamCabecera);
        while ((strcmp(regIS.indice.claveSec,claveSec)==0)&&((centro*cabecera->tamMaxReg+tamCabecera)>=tamCabecera))
        {
            aux.push_back(regIS.indice.clavePrim);
            centro--;
            if (LeerRegistroIS(regIS,centro*cabecera->tamMaxReg+tamCabecera)==-1)break;
        }
        for (unsigned int i=0;i<aux.size(); i++)
        {
            pos=indiceFicPrimario.busquedaBinariaIP(const_cast<char*>(aux[i].c_str()),false);
            if (pos==-1)cout<<"Registro con clave "<<aux[i]<<" no encontrado o eliminado"<<endl;
            if (ESFileDatos.LeerRegistro(reg,pos)!=-1)
            {
                cout<<reg<<endl;
                validos++;
            }
        }
        return validos;
    }
    else
        return -1;
}

long INDICE::EliminarRegistroIP(long pos)
{
    registroIP regIP;
    int tamIndice=cabecera->tamMaxReg;
    long posFinArchivo=cabecera->numRegs*tamIndice+tamCabecera;
    long posActual,posReg;

    posReg=LeerRegistroIP(regIP,pos);
    posActual=pos+tamIndice;//me posiciono en el siguiente

    while (posActual<posFinArchivo&&cabecera->numRegs>0)//mientras no llegemos al final de archivo y siga habiendo registros
    {
        LeerRegistroIP(regIP,posActual);
        fichero.seekp(posActual-tamIndice,ios::beg);
        regIP.EstablecerCadenaRegistro(ESRegBinario->GetCadenaRegistro());
        if (EscribirCadenaRegistro()==-1)return -1;//el siguiente al actual lo escribo en actual es decir, el i+1 en i
        posActual+=tamIndice;//avanzo al siguiente
    }
    cabecera->numRegs--;
    return posReg;
}

long INDICE::InsertarRegistroIP(registroIP &regIPNuevo)
{
    registroIP regIPAux;
    int tamIndice=cabecera->tamMaxReg;
    long posActual=tamIndice*(cabecera->numRegs-1)+tamCabecera;
    bool encontrado;

    while (posActual>=tamCabecera && !encontrado)
    {
        LeerRegistroIP(regIPAux,posActual);
        if (regIPAux>regIPNuevo)
        {
            fichero.seekp(posActual+tamIndice,ios::beg);
            regIPAux.EstablecerCadenaRegistro(ESRegBinario->GetCadenaRegistro());
            EscribirCadenaRegistro();
            posActual=posActual-tamIndice;
        }
        else
            encontrado=true;
    }

    fichero.seekp(posActual+tamIndice,ios::beg);
    regIPNuevo.EstablecerCadenaRegistro(ESRegBinario->GetCadenaRegistro());
    EscribirCadenaRegistro();

    return posActual+tamIndice;
}

long INDICE::InsertarRegistroIS(registroIS &regISNuevo)
{
    registroIS regISAux;
    int tamIndice=cabecera->tamMaxReg;
    long posActual=tamIndice*(cabecera->numRegs-1)+tamCabecera;
    bool encontrado=false;

    while (posActual>=tamCabecera && !encontrado)
    {
        LeerRegistroIS(regISAux,posActual);
        if (regISAux>regISNuevo)
        {
            fichero.seekp(posActual+tamIndice,ios::beg);
            regISAux.EstablecerCadenaRegistro(ESRegBinario->GetCadenaRegistro());
            EscribirCadenaRegistro();
            posActual=posActual-tamIndice;
        }
        else
            encontrado=true;
    }

    fichero.seekp(posActual+tamIndice,ios::beg);
    regISNuevo.EstablecerCadenaRegistro(ESRegBinario->GetCadenaRegistro());

    EscribirCadenaRegistro();

    return posActual;
}

int INDICE::InsertarNuevosRegistros(fstream &ficheroTxt,INDICE &indiceFicSecundario ,ESFicheroBinario &ESFileDatos)
{
    registroIP regIP;
    registroIS regIS;
    Registro registro;
    char *cadenaRegistroTxt=new char[200];
    int numRegsInsertados=0;
    long pos;

    while (!ficheroTxt.eof())
    {
        ESFileDatos.LimpiarCadena(cadenaRegistroTxt);
        if (ESFileDatos.LeerRegistroTxt(ficheroTxt,cadenaRegistroTxt)==-1)
            break;
        pos=ESFileDatos.InsertarRegistro(cadenaRegistroTxt);
        if (pos!=-1)
        {
            registro.ObtenerCadenaRegistro(ESFileDatos.ESRegBinario->GetCadenaRegistro());
            strcpy(regIP.indice.clavePrim,registro.Bridge.Id);
            regIP.indice.posicionReg=pos;
            InsertarRegistroIP(regIP);
            strcpy(regIS.indice.clavePrim,registro.Bridge.Id);
            switch (posClave)
            {
            case 1:
                sprintf(regIS.indice.claveSec,"%c",registro.Bridge.River);
                break;
            case 2:
                sprintf(regIS.indice.claveSec,"%d",registro.Bridge.Location);
                break;
            case 3:
                sprintf(regIS.indice.claveSec,"%d",registro.Bridge.Erected);
                break;
            case 4:
                strcpy(regIS.indice.claveSec,registro.Bridge.Purpose);
                break;
            }
            indiceFicSecundario.InsertarRegistroIS(regIS);
            cabecera->numRegs++;
            indiceFicSecundario.cabecera->numRegs++;
            numRegsInsertados++;
        }
    }
    ESFileDatos.cabecera->numRegs+=numRegsInsertados;
    delete cadenaRegistroTxt;

    return numRegsInsertados;
}
//M�todos de la Clase registroIP:
void registroIP::EstablecerCadenaRegistro(char* cadenaRegistro)
{
    sprintf(cadenaRegistro,"%s|%ld|",indice.clavePrim,indice.posicionReg);
}
void registroIP::ObtenerCadenaRegistro(char* cadenaRegistro)
{
    strcpy(indice.clavePrim,strtok(cadenaRegistro,"|"));
    indice.posicionReg=atol(strtok(NULL,"|"));
}
void registroIP::Mostrar()
{
    cout<<endl<<"<< Indice Primario >>"<<endl;
    cout<<"Clave primaria: "<<indice.clavePrim<<endl;
    cout<<"Posicion del registro: "<<indice.posicionReg<<endl;
}
ostream& operator<<(ostream& os,const registroIP& p)
{
    os<<p.indice.clavePrim<<"|"<<p.indice.posicionReg<<"|";
    return os;
}
bool registroIP::operator<(const char* otra)
{
    return atoi(indice.clavePrim+1)<atoi(otra+1)?true:false;
}
bool registroIP::operator<=(const char* otra)
{
    return atoi(indice.clavePrim+1)<=atoi(otra+1)?true:false;
}
bool registroIP::operator>(const char* otra)
{
    return atoi(indice.clavePrim+1)>atoi(otra+1)?true:false;
}
bool registroIP::operator>=(const char* otra)
{
    return atoi(indice.clavePrim+1)>=atoi(otra+1)?true:false;
}
bool registroIP::operator>(const registroIP &otro)
{
    return atoi(indice.clavePrim+1)>atoi(otro.indice.clavePrim+1)?true:false;
}
//FIN

//M�todos de la Clase registroIS:
void registroIS::EstablecerCadenaRegistro(char* cadenaRegistro)
{
    sprintf(cadenaRegistro,"%s|%s|",indice.claveSec,indice.clavePrim);
}
void registroIS::ObtenerCadenaRegistro(char* cadenaRegistro)
{
    strcpy(indice.claveSec,strtok(cadenaRegistro,"|"));
    strcpy(indice.clavePrim,strtok(NULL,"|"));
}
void registroIS::Mostrar()
{
    cout<<endl<<"<< Indice Secundario >>"<<endl;
    cout<<"Clave secundaria: "<<indice.claveSec<<endl;
    cout<<"Clave primaria: "<<indice.clavePrim<<endl;
}
ostream& operator<<(ostream& os,const registroIS& p)
{
    os<<p.indice.claveSec<<"|"<<p.indice.clavePrim<<"|";
    return os;
}
bool registroIS::operator>(const registroIS &otro)
{
    return strcmp(indice.claveSec,otro.indice.claveSec)>0?true:false;
}
//FIN
