#include "EntradaSalida.hpp"
//Metodos ESFicheroBinario
ESFicheroBinario::ESFicheroBinario(char* nombreFichero, int tamMax, modoApertura mA)
{
    ESRegBinario = new ESRegistroBinario(tamMax);
    cabecera=new CABECERA();
    tamCabecera=sizeof(CABECERA);
    switch (mA)
    {
    case r://abre el fichero para operaciones de lectura
        fichero.open(nombreFichero, ios::in|ios::binary);
        ObtenerCabecera();
        break;
    case w://abre el fichero para operaciones de  escritura
        fichero.open(nombreFichero, ios::out|ios::binary);
        cabecera->tamMaxReg=tamMax;
        cabecera->numRegs=0;
        cabecera->tope=-1;//inicializacion de tope
        EscribirCabecera();
        break;
    case rw://abre el fichero para operaciones de lectura/escritura
        fichero.open(nombreFichero,ios::in|ios::out|ios::binary);
        ObtenerCabecera();
        break;
    }
    if (fichero==NULL)
        cout<<"Error al abrir el fichero "<<nombreFichero<<endl;
}
ESFicheroBinario::~ESFicheroBinario()
{
    delete ESRegBinario;
    delete cabecera;
    if (fichero)
        fichero.close();
}
void ESFicheroBinario::ObtenerCabecera()
{
    fichero.seekg(0,ios::beg);
    fichero.read((char*)cabecera,tamCabecera);
}
void ESFicheroBinario::EscribirCabecera()
{
    fichero.seekp(0,ios::beg);
    fichero.write((char*)cabecera,tamCabecera);
}
void ESFicheroBinario::LimpiarCadena(char *cadena)
{
    cadena[0]='\0';
}
int ESFicheroBinario::GenerarArchivoBinario(fstream &ficheroTxt)
{
    char *cadenaRegistroTxt=new char[200];
    while (!ficheroTxt.eof())
    {
        LimpiarCadena(cadenaRegistroTxt);
        if (LeerRegistroTxt(ficheroTxt,cadenaRegistroTxt)==-1)
            break;
        FormatearCadenaRegistro(cadenaRegistroTxt);
        cout<<ESRegBinario->GetCadenaRegistro()<<endl;
        if (EscribirCadenaRegistro()!=-1)
            cabecera->numRegs++;
    }
    delete cadenaRegistroTxt;
    return cabecera->numRegs;
}
int ESFicheroBinario::LeerRegistroTxt(fstream &ficheroTxt, char *cadenaRegistroTxt)
{
    ficheroTxt.getline(cadenaRegistroTxt,200);
    if (!ficheroTxt.good())
        return -1;
    return 0;
}
long ESFicheroBinario::LeerCadenaRegistro()
{
    long pos=fichero.tellg();//obtengo posicion del puntero get
    fichero.read(ESRegBinario->GetCadenaRegistro(),cabecera->tamMaxReg);//leo registro en propiedad de Clase
    //cout<<ESRegBinario->GetCadenaRegistro()<<endl<<cabecera->tamMaxReg;
    if (!fichero.good())
        return -1;
    return pos;
}
long ESFicheroBinario::EscribirCadenaRegistro()
{
    long pos=fichero.tellp();//obtengo posicion del puntero put
    fichero.write(ESRegBinario->GetCadenaRegistro(),cabecera->tamMaxReg);
    if (!fichero.good())
        return -1;
    return pos;
}
void ESFicheroBinario::FormatearCadenaRegistro(char *cadenaRegistroTxt)
{
    char *cadenaRegistro=ESRegBinario->GetCadenaRegistro();
    char *campo;
    LimpiarCadena(cadenaRegistro);
    strcpy(cadenaRegistro,"1|");
    campo=(char*)strtok(cadenaRegistroTxt,",");
    for (int i=0;i<13;i++)
    {
        if (campo)
        {
            strcat(cadenaRegistro,campo);
            strcat(cadenaRegistro,"|");
        }
        campo=(char*)strtok(NULL,",");
    }
}
long ESFicheroBinario::BuscarRegistro(int numCampo, char* valor)
{
    Registro registro;
    long pos;
    while (!fichero.eof())
    {
        pos=LeerRegistro(registro);
        if (pos!=-1 && strcmp(registro.Bridge.Id,valor) == 0)
            return pos;
    }
    return -1;
}
long ESFicheroBinario::LeerRegistro(Registro &registro, long pos)
{
    fichero.seekg(pos,ios::beg);
    return LeerRegistro(registro);
}
long ESFicheroBinario::LeerRegistro(Registro &registro)
{
    long pos=LeerCadenaRegistro();
    if (pos==-1)
        return -1;
    if (registro.ObtenerCadenaRegistro(ESRegBinario->GetCadenaRegistro())==-1)
        return -1;
    return pos;
}
long ESFicheroBinario::ObtenerRegistro(int NRR)
{
    long pos;
    long posFinArchivo;
    pos=tamCabecera + NRR*cabecera->tamMaxReg;
    fichero.seekg(0,ios::end);
    posFinArchivo=fichero.tellg();
    if (pos>=posFinArchivo)
        return -1;
    return pos;
}
long ESFicheroBinario::InsertarNuevosRegistros(fstream &ficheroTxt)
{
    char *cadenaRegistroTxt=new char[200];
    int numRegsInsertados=0;
    while (!fichero.eof())
    {
        LimpiarCadena(cadenaRegistroTxt);
        if (LeerRegistroTxt(ficheroTxt,cadenaRegistroTxt)==-1) break;
        if (InsertarRegistro(cadenaRegistroTxt)!=-1) numRegsInsertados++;
    }
    cabecera->numRegs+=numRegsInsertados;
    delete cadenaRegistroTxt;

    return numRegsInsertados;
}
long ESFicheroBinario::InsertarRegistro(char* cadenaRegistroTxt)
{
    long tope,topeAnt;
    char bitBorrado[2];
    FormatearCadenaRegistro(cadenaRegistroTxt);
    cout<<ESRegBinario->GetCadenaRegistro()<<endl;
    if (cabecera->tope!=-1)
    {
        fichero.seekg(cabecera->tope,ios::beg);
        fichero.read(bitBorrado,BITBORRADO);
        fichero.read((char*)&topeAnt,sizeof(long));
        tope=cabecera->tope;
        cabecera->tope=topeAnt;
        fichero.seekp(tope,ios::beg);
    }
    else
        fichero.seekp(0,ios::end);//no hay registros borrados

    return EscribirCadenaRegistro();
}
long ESFicheroBinario::EliminarRegistro(long pos)
{
    fichero.seekp(pos,ios::beg);//posicion absoluta de reg a eliminar
    fichero.write("0|",BITBORRADO);
    fichero.write((char*)&cabecera->tope,sizeof(long));//guardo tope
    if (!fichero.good())return -1;
    cabecera->tope=pos;
    cabecera->numRegs--;
    return pos;
}
int ESFicheroBinario::ListarRegistros()
{
    int numRegs=0;
    Registro registro;
    while (!fichero.eof())
        if (LeerRegistro(registro)!=-1)
        {
            cout<<registro<<endl;
            numRegs++;
        }
    return numRegs;
}

//Metodos Registro
int Registro::ObtenerCadenaRegistro(char* cadenaRegistro)
{
    char *campo=(char*)strtok(cadenaRegistro,"|");
    char bitBorrado=campo[0];
    if (bitBorrado!='1')return -1;
    campo=(char*)strtok(NULL,"|");
    strcpy(Bridge.Id,campo);
    campo=(char*)strtok(NULL,"|");
    Bridge.River=campo[0];
    campo=(char*)strtok(NULL,"|");
    Bridge.Location=atoi(campo);
    campo=(char*)strtok(NULL,"|");
    Bridge.Erected=atoi(campo);
    campo=(char*)strtok(NULL,"|");
    strcpy(Bridge.Purpose,campo);
    campo=(char*)strtok(NULL,"|");
    Bridge.Length=atoi(campo);
    campo=(char*)strtok(NULL,"|");
    Bridge.Lanes=atoi(campo);
    campo=(char*)strtok(NULL,"|");
    Bridge.ClearG=campo[0];
    campo=(char*)strtok(NULL,"|");
    strcpy(Bridge.TOrD,campo);
    campo=(char*)strtok(NULL,"|");
    strcpy(Bridge.Material,campo);
    campo=(char*)strtok(NULL,"|");
    strcpy(Bridge.Span,campo);
    campo=(char*)strtok(NULL,"|");
    strcpy(Bridge.Rel,campo);
    campo=(char*)strtok(NULL,"|");
    strcpy(Bridge.Type,campo);
    return 0;
}
void Registro::EstablecerCadenaRegistro(char* cadenaRegistro)
{
    sprintf(cadenaRegistro,"%c|%s|%c|%d|%d|%s|%d|%d|%c|%s|%s|%s|%s|%s|",'1',Bridge.Id,Bridge.River,Bridge.Location,Bridge.Erected,
            Bridge.Purpose,Bridge.Length,Bridge.Lanes,Bridge.ClearG,Bridge.TOrD,Bridge.Material,Bridge.Span,Bridge.Rel,Bridge.Type);
}
void Registro::Mostrar()
{
    cout<<"\tREGISTRO "<<endl<<endl;
    cout<<"\tId: "<<Bridge.Id<<endl;
    cout<<"\tRiver: "<<Bridge.River<<endl;
    cout<<"\tLocation: "<<Bridge.Location<<endl;
    cout<<"\tErected: "<<Bridge.Erected<<endl;
    cout<<"\tPurpose: "<<Bridge.Purpose<<endl;
    cout<<"\tLength: "<<Bridge.Length<<endl;
    cout<<"\tLanes: "<<Bridge.Lanes<<endl;
    cout<<"\tClearG: "<<Bridge.ClearG<<endl;
    cout<<"\tT-Or-D: "<<Bridge.TOrD<<endl;
    cout<<"\tMaterial: "<<Bridge.Material<<endl;
    cout<<"\tSpan: "<<Bridge.Span<<endl;
    cout<<"\tRel: "<<Bridge.Rel<<endl;
    cout<<"\tType: "<<Bridge.Type<<endl;
}
ostream& operator<<(ostream& os,const Registro& p)
{
    os<<p.Bridge.Id<<"|"<<p.Bridge.River<<"|"<<p.Bridge.Location<<"|"<<p.Bridge.Erected<<"|"<<p.Bridge.Purpose<<"|"<<
    p.Bridge.Length<<"|"<<p.Bridge.Lanes<<"|"<<p.Bridge.ClearG<<"|"<<p.Bridge.TOrD<<"|"<<p.Bridge.Material<<"|"<<
    p.Bridge.Span<<"|"<<p.Bridge.Rel<<"|"<<p.Bridge.Type<<"|";
    return os;
}

bool Registro::operator>(const Registro &otro)
{
    return atoi(Bridge.Id+1)>atoi(otro.Bridge.Id+1)?true:false;
}
bool Registro::operator<(const Registro &otro)
{
    return atoi(Bridge.Id+1)<atoi(otro.Bridge.Id+1)?true:false;
}
//Metodos ESRegistroBinario
ESRegistroBinario::ESRegistroBinario(int tamMax)
{
    tamMaxRegistro=tamMax;
    cadenaRegistro=new char[tamMax];
}
ESRegistroBinario::~ESRegistroBinario()
{
    delete cadenaRegistro;
}
