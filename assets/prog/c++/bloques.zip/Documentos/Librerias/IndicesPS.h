#ifndef INDICESPS_H_INCLUDED
#define INDICESPS_H_INCLUDED
#include "EntradaSalida.hpp"
#include <vector>
#define POS_PRIMARIO 0

enum tipoIndice {primario=1,secundario};

typedef struct
{
    char clavePrim[6];
    long posicionReg;

}INDICEP;

typedef struct
{
    char claveSec[9];
    char clavePrim[6];
}INDICES;

class registroIP
{
private:
    INDICEP indice;
public:
    void ObtenerCadenaRegistro(char* cadenaRegistro); //Obtiene el valor de la cadena para guardar la informaci�n en el STRUCT.
    void EstablecerCadenaRegistro(char* cadenaRegistro); //Establece el valor de la cadena en base a la informaci�n del STRUCT.
    void Mostrar(); //Muestra los campos del registro.
    friend ostream& operator<<(ostream&,const registroIP&);//Muestra los campos del registro en formato condensado
    bool operator<(const char*);
    bool operator<=(const char*);
    bool operator>=(const char*);
    bool operator>(const char*);
    bool operator>(const registroIP&);
    friend class INDICE;
    friend class INDICEND;
    friend class FileBloques;
    friend int compareRegistrosIP(const void *a,const void *b);
};

class registroIS
{
private:
    INDICES indice;

public:
    void ObtenerCadenaRegistro(char* cadenaRegistro); //Obtiene el valor de la cadena para guardar la informaci�n en el STRUCT.
    void EstablecerCadenaRegistro(char* cadenaRegistro); //Establece el valor de la cadena en base a la informaci�n del STRUCT.
    void Mostrar(); //Muestra los campos del registro.
    friend ostream& operator<<(ostream&,const registroIS&);//Muestra los campos del registro en formato condensado
    bool operator>(const registroIS&);
    friend class INDICE;
    friend int compareRegistrosIS(const void *a,const void *b);
};

class INDICE:public ESFicheroBinario
{
    tipoIndice tI; //vale 1 o 2 (primario/secundario)
    int posClave; //indice del campo del registro que forma la clave.
    bool modif; //Flag para indicar si el indice ha sido modificado.
    //Crea el indice primario
    int creaIndicePrimario(ESFicheroBinario &ESFicBinarioReg);
    //Crea el indice secundario
    int creaIndiceSecundario(ESFicheroBinario &ESFicBinarioReg);
    //Muestra un listado del archivo de indices primario
    int listarIndicePrimario();
    //Muestra un listado del archivo de indices secundario
    int listarIndiceSecundario();
    //Muestra un listado ordenado del archivo de datos en base al indice primario
    int listarRegistrosOrdenadoIP(ESFicheroBinario &ESFicBinarioReg);
    //Muestra un listado ordenado del archivo de datos en base al indice secundario
    int listarRegistrosOrdenadoIS(ESFicheroBinario &ESFicBinarioReg,char* iPrim);
public:
    //Ahora inicializamos la clase INDICE, para eyo se crea primero el indice en memoria y despues se vuelca al fichero indice.
    INDICE(char* nombreFichero,int tamMax,modoApertura mA,tipoIndice tI,int posClave);
    ~INDICE();
    //Rutina publica para crear el indice adecuado
    int creaIndice(ESFicheroBinario &ESFicBinarioReg);
    //Rutina publica para mostrar el archivo de indices
    int listarIndice();
    //Muestra un listado ordenado del archivo de datos en base al indice
    int listarRegistrosOrdenado(ESFicheroBinario &ESFicRegistros,char* ="");
    //M�todos para leer y escribir un registro del indice.
    long LeerRegistroIP(registroIP &indicePrimario);
    long LeerRegistroIS(registroIS &indiceSecundario);
    long LeerRegistroIP(registroIP &indicePrimario,long pos);
    long LeerRegistroIS(registroIS &indiceSecundario,long pos);
    //M�todos para insertar y eliminar un registro indice primario.
    long InsertarRegistroIP(registroIP &indicePrimario);
    long EliminarRegistroIP(long pos);

    //M�todos para insertar y eliminar un registro indice secundario
    long InsertarRegistroIS(registroIS &indiceSecundario);
    long EliminarRgistroIS(long pos);

    int InsertarNuevosRegistros(fstream &ficheroTxt,INDICE &indiceFicSecundario,ESFicheroBinario &ESFicRegistros);

    //M�todos para buscar un registro a partir de la clave primaria o de la clave secundaria. Para ello utilizamos el algoritmo de busqueda binaria en disco.
    long busquedaBinariaIP(char *clavePrim,bool posEnIndice);
    int busquedaBinariaIS(char *claveSec, INDICE &indiceFicPrimario, ESFicheroBinario &ESFicRegistros);
};


#endif // INDICESPS_H_INCLUDED
