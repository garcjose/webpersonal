#ifndef INDICENODENSO_H_INCLUDED
#define INDICENODENSO_H_INCLUDED
#include "IndicesPS.h"

//Estructura que dara forma al bloque
typedef struct
{
    long posSig;
    int nRegs;
    char* cadRegs;
}BLOQUE;

//Clase que anyadira las funcionalidades al bloque
class BloqueIND
{
private:
    BLOQUE bloque;
    friend class INDICEND;
    friend class FileBloques;
public:
    BloqueIND(int tamMaxBloque,int sig=-1);
    ~BloqueIND();
    //Anyade un registro al bloque
    int addReg(Registro&);
    //Resetea el bloque
    void clear();
    //Permite obtener el registro i del bloque de zona maestra
    int getReg(int i,Registro&);
    //Permite obtener el ultimo registro del bloque de zona maestra
    int getUltimoReg(Registro&);
    //Busca el registro con clave primaria valor en el bloque de zona maestra
    bool buscar(char* valor);
    //Convierte el bloque en un vector de registros para facilitar insercion
    void toVector(vector<Registro>&);
    //Permite eliminar el ultimo registro del bloque de zona maestra
    int eliminarUltimoReg(int maxRegs);
    //Obtiene el valor de la cadena para guardar la informaci�n en el STRUCT.
    void ObtenerCadenaBloque(char* cadenaRegistro);
    //Establece el valor de la cadena en base a la informaci�n del STRUCT.
    int EstablecerCadenaBloque(char* cadenaRegistro);
    //Muestra el bloque
    void mostrar();
    //Muestra el bloque en formato condensado
    friend ostream& operator<<(ostream&,const BloqueIND&);
    //Sobrecarga del operador ++ para aumentar el nRegs
    BloqueIND& operator++(int);
    //Sobrecarga del operador =
    BloqueIND& operator=(const BloqueIND&);
};

class INDICEND:public ESFicheroBinario
{
private:
    tipoIndice tI; //vale 1 o 2 (primario/secundario)
    int posClave; //indice del campo del registro que forma la clave.
    bool modif; //Flag para indicar si el indice ha sido modificado.

public:
    //Constructor de la clase INDICEND, hereda de ESFicheroBinario anaydiendo nuevas funcionalidades
    INDICEND(char* nombreFichero,int tamMax,modoApertura mA,tipoIndice tI,int posClave);
    ~INDICEND();
    //Metodo que creara el indice del archivo de bloques
    int creaIndiceNoDenso(FileBloques&);
    //Realiza un listado de los registros del indice
    int listarIndiceNoDenso();
    //Realiza un listado ordenado de los registros del archivo de bloques
    int listarOrdenadoIPNoDenso(FileBloques& fileBloques);
    //Busca un registro a partir de la clave primaria devolviendo o la posicion de indice o la del bloque
    long busquedaBinariaIPNoDenso(char *clave,bool posEnIndice);
    //Inserta nuevos registros en el archivo de bloques desde ficheroTxt
    int InsertarNuevosRegistros(fstream &ficheroTxt,FileBloques &fileBloques);
    //M�todos para leer un registro del indice.
    long LeerRegistroIP(registroIP &indicePrimario);
    long LeerRegistroIP(registroIP &indicePrimario,long pos);
};

class FileBloques:public ESFicheroBinario
{
private:
    int factorCarga;//factor de carga del bloque
    int tamMaxReg;  //tamanyo maximo de registros de cada bloque
    //insertara ordenado un regitro en el bloque b
    char* insertarOrdenado(Registro& reg,BloqueIND& b);
    //Obtiene en blast ultimo bloque de la lista de b y devuelve su posicion
    long getUltimoLista(BloqueIND& b,BloqueIND& blast);
    friend class INDICEND;
public:
    //Constructor de FileBloques, tamMax sera el tamanyo de bloque y tmR el de registro
    FileBloques(char* nombreFichero,int tamMax,modoApertura mA,int fc,int tmR);
    ~FileBloques();
    //Metodo que creara el archivo de bloques con factorCarga registros en cada bloque
    int creaArchivoBloques(ESFicheroBinario&,INDICE&);
    //Realiza un listado de los bloques del archivo
    int listarBloques();
    //Lee un bloque del archivo binario y lo guarda en un STRUCT.
    long LeerBloque(BloqueIND &b);
    long LeerBloque(BloqueIND &b, long pos);
    //Inserta un registro en el archivo de bloques de pos
    char* InsertarRegistro(Registro& reg,long pos);
    //Inserta un registro en el archivo de bloques enlazando b
    char* InsertaryEnlazarEnzonaOverflow(Registro& reg,BloqueIND &b,long posBloque);
    //Realiza la busqueda de valor en los registros de los bloques enlazados a b
    int buscarRegZonaOverFlown(BloqueIND& b,char* valor);
};
#endif
