#include "IndiceNODENSO.hpp"
//Funcion para tokenizar usando string
void Tokenize(const string& str,vector<string>& tokens,const string delimiters)
{
    // Salto delimiters del principio
    string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    // Encuentro el primer "non-delimiter".
    string::size_type pos     = str.find_first_of(delimiters, lastPos);

    while (string::npos != pos || string::npos != lastPos)
    {
        // Encuentro token, y lo anaydo al vector
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        // Salto delimiters de nuevo
        lastPos = str.find_first_not_of(delimiters, pos);
        // Encuentro el siguiente "non-delimiter"
        pos = str.find_first_of(delimiters, lastPos);
    }
}
//METODOS INDICEND
INDICEND::INDICEND(char* nombreFichero,int tamMax,modoApertura mA,tipoIndice tipInd,int pos)
        :ESFicheroBinario(nombreFichero,tamMax,mA)
{
    tI=tipInd;
    posClave=pos;
    modif=false;
}

INDICEND::~INDICEND() {}

int INDICEND::creaIndiceNoDenso(FileBloques& fileBloques)
{
    Registro reg;
    BloqueIND b(fileBloques.cabecera->tamMaxReg);//bloque auxiliar
    registroIP regIP;
    int numIndices=0;
    long pos;
    while (!fileBloques.fichero.eof())
    {
        pos=fileBloques.LeerBloque(b);//leo bloque
        if (pos!=-1)
        {
            b.getUltimoReg(reg);//obtengo reg en last post
            regIP.indice.posicionReg=pos;
            strcpy(regIP.indice.clavePrim,reg.Bridge.Id);//inicializao registro IP
            numIndices++;
            regIP.EstablecerCadenaRegistro(ESRegBinario->GetCadenaRegistro());
            if (EscribirCadenaRegistro()==-1)return -1;
            cout<<regIP<<endl;
        }
    }
    cabecera->numRegs=numIndices;
    return numIndices;
}
int INDICEND::listarIndiceNoDenso()
{
    registroIP regIndiceP;
    for (int i=0;i<cabecera->numRegs;i++)
    {
        if (LeerRegistroIP(regIndiceP)==-1)return -1;
        cout<<regIndiceP<<endl;
    }
    return cabecera->numRegs;
}
int INDICEND::listarOrdenadoIPNoDenso(FileBloques& fileBloques)
{
    registroIP regIP;
    long pos;
    BloqueIND b(fileBloques.cabecera->tamMaxReg);
    int i;
    for (i=0;i<cabecera->numRegs;)
    {
        if (LeerRegistroIP(regIP)==-1)break;
        if (fileBloques.LeerBloque(b,regIP.indice.posicionReg)!=-1)
        {
            b.mostrar();
            i++;
            while ((pos=b.bloque.posSig)!=-1)
            {
                fileBloques.LeerBloque(b,pos);
                b.mostrar();//voy mostrando bloques enlazados a b
                i++;
            }
        }
        else return -1;
    }
    return i;//marcara el numero de bloques mostrados
}
long INDICEND::busquedaBinariaIPNoDenso(char *clave,bool posEnIndice)
{
    int inf=0;
    int sup=(cabecera->numRegs)-1;
    int centro=0;
    long pos;
    registroIP regIP;
    registroIP auxIP;
    while (inf<=sup)
    {
        centro=(inf+sup)/2;
        if (LeerRegistroIP(regIP,centro*cabecera->tamMaxReg+tamCabecera)==-1)return -1;
        if (regIP>=clave)   //si es mayor o igual que clave puede ser el correcto
        {
            centro--;
            if (LeerRegistroIP(auxIP,centro*cabecera->tamMaxReg+tamCabecera)==-1)
            {
                pos=(centro+1)*cabecera->tamMaxReg+tamCabecera;
                break;//si llega aqui sera porque es el primer bloque
            }
            if (auxIP<clave)   //comprobamos si el anterior a regIP es menor que la clave
            {
                //si es asi lo hemos encontrado actualizamos pos
                centro++;
                pos=centro*cabecera->tamMaxReg+tamCabecera;
                break;
            }
            sup=centro;//no lo hemos encontrado actualizamos limites
        }
        else if (regIP<clave)   //realizamos las mismas comprobaciones pero al reves
        {
            centro++;
            if (LeerRegistroIP(regIP,centro*cabecera->tamMaxReg+tamCabecera)==-1)
            {
                pos=(centro-1)*cabecera->tamMaxReg+tamCabecera;
                break;//si llega aqui sera porque es el ultimo bloque
            }
            if (regIP>=clave)
            {
                pos=centro*cabecera->tamMaxReg+tamCabecera;
                break;
            }
            inf=centro;//no lo hemos encontrado actualizamos limites
        }
    }
    fichero.clear();//limpiamos flags
    //devolvemos la posicon del registro en indice o la posicion del registro real de datos
    return posEnIndice? pos:regIP.indice.posicionReg;
}
int INDICEND::InsertarNuevosRegistros(fstream &ficheroTxt,FileBloques &fileBloques)
{
    registroIP regIP;
    Registro registro;
    char *cadenaRegistroTxt=new char[200];
    int numRegsInsertados=0;
    long posBloque,posIndice;
    char* claveIndice;
    while (!ficheroTxt.eof())
    {
        //leeemos la cadena desde el txt y convertimos en registro
        fileBloques.LimpiarCadena(cadenaRegistroTxt);
        if (fileBloques.LeerRegistroTxt(ficheroTxt,cadenaRegistroTxt)==-1)break;
        fileBloques.FormatearCadenaRegistro(cadenaRegistroTxt);
        cout<<fileBloques.ESRegBinario->GetCadenaRegistro()<<endl;
        registro.ObtenerCadenaRegistro(fileBloques.ESRegBinario->GetCadenaRegistro());
        //hallamos posiciones del bloque y del indice correspondientes
        posBloque=busquedaBinariaIPNoDenso(registro.Bridge.Id,false);
        posIndice=busquedaBinariaIPNoDenso(registro.Bridge.Id,true);
        //insertamos registro en bloque correspondiente
        claveIndice=fileBloques.InsertarRegistro(registro,posBloque);
        fileBloques.cabecera->numRegs++;
        numRegsInsertados++;
        //actualizamos si es necesario ultima clave de bloque
        if (claveIndice)
        {
            if (LeerRegistroIP(regIP,posIndice)==-1)return -1;
            if (strcmp(regIP.indice.clavePrim,claveIndice)!=0)
            {
                strcpy(regIP.indice.clavePrim,claveIndice);
                fichero.seekp(posIndice,ios::beg);
                regIP.EstablecerCadenaRegistro(ESRegBinario->GetCadenaRegistro());
                if (EscribirCadenaRegistro()==-1)return -1;
            }
            delete[] claveIndice;
        }
    }
    delete[] cadenaRegistroTxt;
    return numRegsInsertados;
}
long INDICEND::LeerRegistroIP(registroIP &regIndice1,long pos)
{
    fichero.seekg(pos,ios::beg);
    return LeerRegistroIP(regIndice1);
}
long INDICEND::LeerRegistroIP(registroIP &regIndice1)
{
    long pos=LeerCadenaRegistro();
    if (pos==-1)return -1;
    regIndice1.ObtenerCadenaRegistro(ESRegBinario->GetCadenaRegistro());
    return pos;
}
//METODOS FILEBLOQUES
FileBloques::FileBloques(char* nombreFichero,int tamMax,modoApertura mA,int fc,int tmR)
        :ESFicheroBinario(nombreFichero,tamMax,mA)
{
    factorCarga=fc;
    tamMaxReg=tmR;
}
FileBloques::~FileBloques() {}
int FileBloques::creaArchivoBloques(ESFicheroBinario& ESfile,INDICE& iP)
{
    registroIP regIP;
    Registro reg;
    BloqueIND b(cabecera->tamMaxReg);//en cabecera guardamos el tamanyo de bloque
    int numRegsInsert=0;
    for (int i=0;i<iP.cabecera->numRegs;i++)
    {
        //leemos tantos registros seguidos como factor de carga
        for (int j=0;j<factorCarga;j++)
        {
            if (iP.LeerRegistroIP(regIP)==-1)break;
            if (ESfile.LeerRegistro(reg,regIP.indice.posicionReg)==-1)return -1;
            b.addReg(reg);//anyadiendo el registro al bloque
            numRegsInsert++;
        }
        //escribimos el bloque
        if (b.EstablecerCadenaBloque(ESRegBinario->GetCadenaRegistro())==-1)break;
        if (EscribirCadenaRegistro()==-1)return -1;
        cout<<b<<endl;
        b.clear();
    }
    cabecera->numRegs=numRegsInsert;//guardo el numRegs en cabecera
    return numRegsInsert;      //parao obtener bloques divido por factorCarga
}
int FileBloques::listarBloques()
{
    //vamos leyendo bloques y mostrando sin mirar lista
    BloqueIND b(cabecera->tamMaxReg);
    int numBloques=0;
    while (!fichero.eof())
        if (LeerBloque(b)!=-1)
        {
            b.mostrar();
            numBloques++;
        }
    return numBloques*factorCarga;
}
char* FileBloques::insertarOrdenado(Registro& reg,BloqueIND& b)
{
    int i=b.bloque.nRegs;
    vector<Registro> regs;
    b.toVector(regs);//convierto bloque en un vector para facilitar tarea de ordenacion
    bool meter=false;
    char* claveIndice=new char[10];//guardaremos ultimaClave
    while (i>0&&!meter)
        if (reg<regs[i-1])   //si el nuevo es menor que i-1
        {
            //muevo i-1 a i
            copy ( regs.begin()+i-1, regs.begin()+i-1, regs.begin()+i );
            i--;
        }
        else meter=true;
    vector<Registro>::iterator it;
    regs.insert(regs.begin()+i,reg);//inserto en pos i
    b.bloque.cadRegs[0]='\0';
    b.bloque.nRegs=0;  //reseteo bloque y anyado los registros ordenados
    for (unsigned int i=0;i<regs.size();i++)b.addReg(regs[i]);
    strcpy(claveIndice,regs[regs.size()-1].Bridge.Id);
    return claveIndice;
}
char* FileBloques::InsertaryEnlazarEnzonaOverflow(Registro& reg,BloqueIND &b,long posBloque)
{
    BloqueIND aux(cabecera->tamMaxReg);//salvo bloque en aux
    aux=b;
    char* claveIndice;
    long pos;//avanzo por la lista hasta que encuentre uno sin siguiente
    while ((pos=aux.bloque.posSig)!=-1)
    {
        if (LeerBloque(aux,pos)==-1)return NULL;
        if (aux.bloque.nRegs<factorCarga)break;//o uno que no este lleno
    }
    if (pos==-1)   //si no tiene siguiente y esta lleno
    {
        BloqueIND newB(cabecera->tamMaxReg);//creo uno nuevo y anyado el nuevo registro
        newB.addReg(reg);
        fichero.seekp(0,ios::end);
        if (newB.EstablecerCadenaBloque(ESRegBinario->GetCadenaRegistro())==-1)return NULL;
        if ((pos=EscribirCadenaRegistro())==-1)return NULL;
        aux.bloque.posSig=pos;              //actualizando enlaces
        fichero.seekp(posBloque,ios::beg);
        if (aux.EstablecerCadenaBloque(ESRegBinario->GetCadenaRegistro())==-1)return NULL;
        if ((pos=EscribirCadenaRegistro())==-1)return NULL;
        claveIndice=new char[10];
        strcpy(claveIndice,reg.Bridge.Id);//guardo clave ultima por si es necesario modificar el indice
    }
    else   //si hay espacio en el bloque
    {
        //inserto en el bloque y recupero clave indice ultima
        claveIndice=insertarOrdenado(reg,aux);
        fichero.seekp(pos,ios::beg);
        if (aux.EstablecerCadenaBloque(ESRegBinario->GetCadenaRegistro())==-1)return NULL;
        if ((pos=EscribirCadenaRegistro())==-1)return NULL;
    }
    return claveIndice;
}
char* FileBloques::InsertarRegistro(Registro &reg,long posBloque)
{
    BloqueIND b(cabecera->tamMaxReg);
    Registro last;
    char* clave;
    long pos;
    if (LeerBloque(b,posBloque)==-1)return NULL;
    if (b.bloque.nRegs<factorCarga)   //insercion en zona maestra si hay espacio
    {
        clave=insertarOrdenado(reg,b);//inserto ordenado
        fichero.seekp(posBloque,ios::beg);
        if (b.EstablecerCadenaBloque(ESRegBinario->GetCadenaRegistro())==-1)return NULL;
        if ((pos=EscribirCadenaRegistro())==-1)return NULL;
        return clave;
    }
    else  //obtengo ultimo bloque de la lista de b
    {
        BloqueIND blast(cabecera->tamMaxReg);
        if (b.bloque.posSig==-1)
        {
            pos=posBloque;
            blast=b;
        }
        else pos = getUltimoLista(b,blast);
        blast.getUltimoReg(last);//obtengo ultimo reg del bloque
        if (blast.bloque.nRegs<factorCarga)   //insercion directa si hay espacio en el ultimo
        {
            clave=insertarOrdenado(reg,blast);
            fichero.seekp(pos,ios::beg);
            if (blast.EstablecerCadenaBloque(ESRegBinario->GetCadenaRegistro())==-1)return NULL;
            if ((pos=EscribirCadenaRegistro())==-1)return NULL;
            return clave;
        }
        else
        {
            //si es menor que el ultimo
            if (reg<last)
            {
                blast.eliminarUltimoReg(factorCarga);//elimino el ultimo
                insertarOrdenado(reg,blast);         //inserto el nuevo
                return InsertaryEnlazarEnzonaOverflow(last,blast,pos);//e inserto el ultimo en zona overflow
            }
            else if (reg>last)//si es mayor que el ultimo inserto el nuevo en zona overflow
                return InsertaryEnlazarEnzonaOverflow(reg,blast,pos);
        }
    }
    return NULL;
}
long FileBloques::getUltimoLista(BloqueIND& b,BloqueIND& blast)
{
    long pos,posBloque;
    blast=b;//si hay siguiente recorro la lista hasta encontra el ultimo
    if (b.bloque.posSig!=-1)
        while ((pos=blast.bloque.posSig)!=-1)if ((posBloque=LeerBloque(blast,pos))==-1)return -1;
    return posBloque;
}

int FileBloques::buscarRegZonaOverFlown(BloqueIND& b,char* valor)
{
    BloqueIND aux(cabecera->tamMaxReg);
    aux=b;         //salvo bloque en aux
    long pos;
    bool encontrado=false;
    vector<string> regs;
    while ((pos=aux.bloque.posSig)!=-1&&!encontrado)    //avanzo por la lista hasta que encuentre uno sin siguiente
    {
        if (LeerBloque(aux,pos)==-1)return -1;
        if (aux.buscar(valor))encontrado=true;
    }
    return encontrado;
}
long FileBloques::LeerBloque(BloqueIND &b, long pos)
{
    fichero.seekg(pos,ios::beg);
    return LeerBloque(b);
}
long FileBloques::LeerBloque(BloqueIND &b)
{
    long pos=LeerCadenaRegistro();
    if (pos==-1)
        return -1;
    b.ObtenerCadenaBloque(ESRegBinario->GetCadenaRegistro());
    return pos;
}
//METODOS BloqueIND
BloqueIND::BloqueIND(int tamMaxBloque,int sig)
{
    bloque.cadRegs=new char[tamMaxBloque];
    bloque.posSig=sig;
    bloque.nRegs=0;
}
BloqueIND::~BloqueIND()
{
    delete[] bloque.cadRegs;
}
int BloqueIND::EstablecerCadenaBloque(char* cadenaRegistro)
{
    if (bloque.nRegs==0)return -1;
    sprintf(cadenaRegistro,"%ld,%d,%s,",bloque.posSig,bloque.nRegs,bloque.cadRegs);
    return 0;
}
void BloqueIND::ObtenerCadenaBloque(char* cadenaRegistro)
{
    bloque.posSig=atol((strtok(cadenaRegistro,",")));
    bloque.nRegs=atoi(strtok(NULL,","));
    strcpy(bloque.cadRegs,(strtok(NULL,",")));
}
void BloqueIND::mostrar()
{
    cout<<endl<<"<< Contenido Bloque >>"<<endl;
    cout<<"Posicion siguiente bloque: "<<bloque.posSig<<endl;
    cout<<"Numero registros en bloque: "<<bloque.nRegs<<endl;
    cout<<"Registros en bloque: "<<endl<<bloque.cadRegs<<endl;
}
ostream& operator<<(ostream& os,const BloqueIND& b)
{
    os<<b.bloque.posSig<<","<<b.bloque.nRegs<<","<<b.bloque.cadRegs<<",";
    return os;
}
BloqueIND& BloqueIND::operator++(int)
{
    bloque.nRegs++;
    return *this;
}
int BloqueIND::addReg(Registro& reg)
{
    //si es el primero lo copio sino lo concateno
    char* buffer= new char[100];
    reg.EstablecerCadenaRegistro(buffer);
    if (bloque.nRegs==0)strcpy(bloque.cadRegs,strcat(buffer,"\n"));
    else strcat(bloque.cadRegs,strcat(buffer,"\n"));
    bloque.nRegs++;//aumenta nRegs
    delete buffer;
    return strlen(bloque.cadRegs);
}
void BloqueIND::clear()
{
    //metodo para resetear bloque
    bloque.nRegs=0;
    bloque.posSig=-1;
    bloque.cadRegs[0]='\0';
}
int BloqueIND::getReg(int i,Registro& reg)
{
    //si esta fuera de rango devuelvo -1
    if (i<0&&i>=bloque.nRegs)return -1;
    char* aux=new char[strlen(bloque.cadRegs)+1];
    strcpy(aux,bloque.cadRegs);//sino tokenizo hasta obtener el reg n
    char* buffer=(char*)strtok(aux,"\n");
    for (int j=1;j<i;j++)buffer=(char*)strtok(NULL,"\n");
    reg.ObtenerCadenaRegistro(buffer);
    int size=strlen(buffer);
    delete[] aux;
    return size;
}
int BloqueIND::getUltimoReg(Registro& reg)
{
    char* aux=new char[strlen(bloque.cadRegs)+1];
    strcpy(aux,bloque.cadRegs);//tokenizo hasta obtener el ultimo reg
    char* buffer=(char*)strtok(aux,"\n");
    for (int j=1;j<bloque.nRegs;j++)buffer=(char*)strtok(NULL,"\n");
    int size=strlen(buffer);
    reg.ObtenerCadenaRegistro(buffer);
    delete[] aux;
    return size;
}
int BloqueIND::eliminarUltimoReg(int maxRegs)
{
    //la funcion strchr devuelve un puntero
    //a la primera ocurrecia del caracter
    //la usamos para obtener la posicion
    //de inicio del ultimo registro y borrarlo
    char* pch = strchr (bloque.cadRegs, '\n');
    for (int i=1;i<maxRegs;i++)pch = strchr (pch+1,'\n');
    bloque.cadRegs[pch-bloque.cadRegs+1]='\0';
    bloque.nRegs--;
    return pch-bloque.cadRegs+1;
}
bool BloqueIND::buscar(char* valor)
{
    Registro reg;
    bool encontrado=false;
    vector<string> aux;
    string copia(bloque.cadRegs);
    Tokenize(copia,aux,"\n");
    for (int i=0;i<bloque.nRegs&&!encontrado;i++)
    {
        //busca en el bloque si esta el registro con clave valor
        reg.ObtenerCadenaRegistro(const_cast<char*>(aux[i].c_str()));
        if (strcmp(reg.Bridge.Id,valor)==0)
        {
            cout<<reg<<endl;
            encontrado=true;
        }
    }
    return encontrado;
}

void BloqueIND::toVector(vector<Registro>& regs)
{
    //convierte en un vector tokenizando el bloque
    Registro reg;
    vector<string> aux;
    string copia(bloque.cadRegs);
    Tokenize(copia,aux,"\n");
    for (int i=0;i<bloque.nRegs;i++)
    {
        reg.ObtenerCadenaRegistro(const_cast<char*>(aux[i].c_str()));
        regs.push_back(reg);
    }
}
BloqueIND& BloqueIND::operator=(const BloqueIND& otro)
{
    bloque.posSig=otro.bloque.posSig;
    bloque.nRegs=otro.bloque.nRegs;
    strcpy(bloque.cadRegs,otro.bloque.cadRegs);
    return *this;
}

