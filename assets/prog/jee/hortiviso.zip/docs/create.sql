
DROP SCHEMA IF EXISTS projectecc;
CREATE SCHEMA projectecc;
USE projectecc;

CREATE TABLE users (
      login VARCHAR(8) NOT NULL,
      password VARCHAR(50) NOT NULL,
      userName VARCHAR(20) NOT NULL,
      surName VARCHAR(40) NOT NULL,
      address VARCHAR(100) NOT NULL,
      email VARCHAR(50) NOT NULL,
      phone VARCHAR(9) NOT NULL,

      CONSTRAINT users_pk PRIMARY KEY ( login )
);

CREATE TABLE orders (
    idOrder BIGINT( 7 ) NOT NULL AUTO_INCREMENT,
    priceFull DECIMAL(10 , 3) NOT NULL ,
    dateOrder DATE NOT NULL ,
    paid ENUM(  'no',  'yes' ) NOT NULL,
    delivered ENUM(  'no',  'yes' ) NOT NULL,
    login VARCHAR(8) NOT NULL,

    CONSTRAINT orders_pk PRIMARY KEY ( idOrder ),
    CONSTRAINT orders_fk FOREIGN KEY ( login ) REFERENCES users ( login ) ON DELETE CASCADE

);

CREATE TABLE products (
    idProduct BIGINT( 7 ) NOT NULL AUTO_INCREMENT,
    typeProduct VARCHAR( 50 ) NOT NULL ,
    kilos INT NOT NULL ,
    priceKilo DECIMAL(5,3) NOT NULL ,
    dateProduct DATE NOT NULL ,
    quality ENUM(  'first',  'second' ) NOT NULL ,
    available ENUM(  'yes',  'no' ) NOT NULL,
    login VARCHAR(8) NOT NULL,
	idOrder BIGINT( 7 ),
	
    CONSTRAINT products_pk PRIMARY KEY ( idProduct ) ,
    CONSTRAINT products_fk FOREIGN KEY ( login ) REFERENCES users ( login ) ON DELETE CASCADE,
    CONSTRAINT products_orders_fk FOREIGN KEY ( idOrder ) REFERENCES orders ( idOrder ) ON DELETE SET NULL
);

