TRUNCATE TABLE users;
TRUNCATE TABLE products;

insert into users(login,password,userName,surName,address,email,phone) values('login1','079323a49c300dcd8dffe1460dede02c','user1Nom','user1Ape','user1Address','joseangel.jstyl8@gmail.com',111111111);

insert into users(login,password,userName,surName,address,email,phone) values('login2','3b38c223cd0767c5e6f40a7fb86159b4','user2Nom','user2Ape','user2Address','user2@user2.com',222222222);

insert into products (typeProduct, kilos, priceKilo, dateProduct, quality, login) values ('prod1', 10, 0.8, '2011-05-15', 'first','login1');

insert into products (typeProduct, kilos, priceKilo, dateProduct, quality, login) values ('prod1', 15, 0.3, '2011-05-15', 'second','login1');

insert into products (typeProduct, kilos, priceKilo, dateProduct, quality, login) values ('prod2', 16, 0.8, '2011-05-17', 'first','login1');

insert into products (typeProduct, kilos, priceKilo, dateProduct, quality, login) values ('prod3', 10, 1.2, '2011-05-15', 'first','login1');

insert into products (typeProduct, kilos, priceKilo, dateProduct, quality, login) values ('prod4', 20, 1.4, '2011-05-18', 'first','login2');

insert into products (typeProduct, kilos, priceKilo, dateProduct, quality, login) values ('prod4', 12, 1.2, '2011-05-19', 'first','login2');
