//Generico
function o(id) {
   return document.getElementById(id);
}

//controlFormularioRegistro
function validarFormRegistro(){
	var error = "Please, before send the form,\nfill the next fields:\n\n";
	var a = ""
	//Patrones
	var reLogin = /\w{3,8}/;
	var rePass = /\w{5,20}/;
	var reEmail = /[\w-\.]{3,}@([\w-]{2,}\.)*([\w-]{2,}\.)[\w-]{2,4}/;
	var reTel = /\d{9}/;
	//Login
    if(!reLogin.test(document.forms.fregistro.login.value))
		a+=' Login 3-8 chars alfanumerics [A-Za-z0-9_]\n';
	//Password
    if(!rePass.test(document.forms.fregistro.password.value))
		a+=' Password 5 o + chars alfanumerics [A-Za-z0-9_]\n';
	//DatosPersonales
    if (document.forms.fregistro.nombre.value == "")		a += " Name\n";
	if (document.forms.fregistro.apellidos.value == "") 	a += " Surname\n";
	if (document.forms.fregistro.domicilio.value == "")	a += " Address\n";
	if(!reEmail.test(document.forms.fregistro.email.value))a+=' Mail Format incorrect\n';
	if(!reTel.test(document.forms.fregistro.telefono.value))a+=' Phone format incorrect (9digits)\n';
	
	 if (a != "") { 
	 	alert(error + a); 
	 	return false;
	 }else{
		//document.forms.fregistro.submit();
                return true;
	 }
}
//controlFormularioLogin
function validarLogin(){
	var reLogin = /\w{3,8}/;
	var rePass = /\w{5,20}/;
	var error = "Please, before send the form,\nfill the next fields:\n\n";
	var a = "";
	//Login
    if(!reLogin.test(document.forms.flogin.login.value))
		a+=' Login 3-8 chars alfanumerics [A-Za-z0-9_]\n';
	//Password
    if(!rePass.test(document.forms.flogin.password.value))
		a+=' Password 5 o + chars alfanumerics [A-Za-z0-9_]\n';
	 if (a != "") { 
	 	alert(error + a); 
	 	return false;
	 }else{
		//document.forms.flogin.submit();
                return true;
	 }
}

//controlFormularioAddProductos
function validarFormAddProductos(){
	var error = "Please, before send the form,\nfill the next fields:\n\n";
	var a = ""
	var reFecha = /\d{4}-\d{2}-\d{2}/;
	var rePrecioKilo = /\d{1,2}.\d{1,3}/;
	//Campos
        if (document.forms.faddProducto.tipo.value == "")		a += " Type\n";
	if (document.forms.faddProducto.kilos.value == "") 	a += " kilos\n"; 
	if(!reFecha.test(document.forms.faddProducto.fecha.value))
		a+=' Date with format YYYY-MM-DD\n';
	if (document.forms.faddProducto.calidad.value == "")	a += " quality\n";
	if(!rePrecioKilo.test(document.forms.faddProducto.precioKilo.value))
		a+=' Price Kilo with format xx.xxx\n';
	
	 if (a != "") { 
	 	alert(error + a); 
	 	return false;
	 }else{
		//document.forms.faddProducto.submit();
                return true;
	 }
}