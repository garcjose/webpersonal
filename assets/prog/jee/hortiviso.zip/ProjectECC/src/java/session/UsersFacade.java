/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package session;

import entity.Users;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Noa
 */
@Stateless
public class UsersFacade extends AbstractFacade<Users> {
    @PersistenceContext(unitName = "ProjectECCPU")
    private EntityManager em;

    protected EntityManager getEntityManager() {
        return em;
    }

    public UsersFacade() {
        super(Users.class);
    }
public boolean loginOK(String loginS, String pass) {
        Users actual = find(loginS);
        if (actual != null && actual.getPassword().equals(md5(pass))) {
            return true;
        } else {
            return false;
        }
    }

    public String md5(String clear) {
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("MD5");
            byte[] b = md.digest(clear.getBytes());
            int size = b.length;
            StringBuffer h = new StringBuffer(size);
            //algoritmo y arreglo md5
            for (int i = 0; i < size; i++) {
                int u = b[i] & 255;
                if (u < 16) {
                    h.append("0" + Integer.toHexString(u));
                } else {
                    h.append(Integer.toHexString(u));
                }
            }
            //clave encriptada
            return h.toString();
        } catch (NoSuchAlgorithmException ex) {
           
        }
        return null;
    }
}
