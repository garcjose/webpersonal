/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Orders;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Noa
 */
@Stateless
public class OrdersFacade extends AbstractFacade<Orders> {

    @PersistenceContext(unitName = "ProjectECCPU")
    private EntityManager em;

    protected EntityManager getEntityManager() {
        return em;
    }

    public OrdersFacade() {
        super(Orders.class);
    }

    public boolean existsNotInProgress(String loginS) {
        List<Orders> listNotInProgress = em.createNamedQuery("Orders.findNotInProgress").getResultList();
        boolean one = false;
        for (Orders o : listNotInProgress) {
            if (o.getUsers().getLogin().equals(loginS)) {
                one = true;
                break;
            }
        }
        return one;
    }
}
