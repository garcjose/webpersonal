/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package session;

import entity.Products;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Noa
 */
@Stateless
public class ProductsFacade extends AbstractFacade<Products> {
    @PersistenceContext(unitName = "ProjectECCPU")
    private EntityManager em;

    protected EntityManager getEntityManager() {
        return em;
    }

    public ProductsFacade() {
        super(Products.class);
    }

    public void noDisponibles(String[] productsID) {
        for (String id : productsID) {
            Products p = find(Long.valueOf(id));
            p.setAvailable("NO");
            edit(p);
        }
    }

    public boolean existsAvailables(String login){
        List<Products> listAvailables=em.createNamedQuery("Products.findByAvailable").setParameter("available", "YES").getResultList();
       boolean one=false;
        for (Products p : listAvailables) {
            if(p.getUsers().getLogin().equals(login)){
                one=true;
                break;
            }
        }
        return one;
    }
}
