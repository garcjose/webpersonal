/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Orders;
import entity.Products;
import entity.Users;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.jms.Queue;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import session.OrdersFacade;
import session.ProductsFacade;
import session.UsersFacade;

/**
 *
 * @author Noa
 */
@WebServlet(name = "ControllerServlet", loadOnStartup = 1,
urlPatterns = {"/index", "/resultOrder", "/login", "/logout", "/flogin", "/doOrder", "/fchangeOrder", "/fdoOrder", "/fdelOrder", "/register", "/fregister", "/manageProducts", "/faddProducts", "/addProducts", "/delProducts"})
public class ControllerServlet extends HttpServlet {

    @Resource(mappedName = "jms/NewEmailFactory")
    private ConnectionFactory connectionFactory;
    @Resource(mappedName = "jms/NewEmail")
    private Queue queue;
    //@EJB
    // private DBManager dbManager;
    @EJB
    private ProductsFacade productsFacade;
    @EJB
    private UsersFacade usersFacade;
    @EJB
    private OrdersFacade ordersFacade;

    @Override
    public void init() throws ServletException {
        // store products list in servlet context
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String userPath = request.getServletPath();
        HttpSession session = request.getSession();
        String loginS = (String) session.getAttribute("login");
        if (userPath.equals("/manageProducts")) {
            //using EJB, mas facil con jstl para products
            if (loginS != null) {
                Users active = usersFacade.find(loginS);
                //session.setAttribute("userProducts", active.getProductsCollection());
                session.setAttribute("userName", active.getUserName());
                session.setAttribute("availables", productsFacade.existsAvailables(loginS));
            }
        } else if (userPath.equals("/doOrder")) {
            if (loginS != null) {
                Users active = usersFacade.find(loginS);
                //session.setAttribute("userProducts", active.getProductsCollection());
                session.setAttribute("userName", active.getUserName());
                session.setAttribute("ordersNotInProgress", ordersFacade.existsNotInProgress(loginS));
            }

        } else if (userPath.equals("/addProducts")) {
        } // if login page is requested
        else if (userPath.equals("/login")) {
            // if register page is requested
        } else if (userPath.equals("/register")) {
        } else if (userPath.equals("/resultOrder")) {
            //muestra datos pedido
        }
        String url = null;
        if (userPath.equals("/index")) {
            url = "/index.jsp";
        } else {
            url = "/WEB-INF/view" + userPath + ".jsp";
        }

        try {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException,
            IOException {

        String userPath = request.getServletPath();

        HttpSession session = request.getSession();
        String loginS, passwordS = null;
        loginS = (String) session.getAttribute("login");

        if (userPath.equals("/flogin")) {
            // Lee formulario
            loginS = (String) request.getParameter("login");
            passwordS = (String) request.getParameter("password");
            //check si exists
            if (usersFacade.loginOK(loginS, passwordS)) {
                session.setAttribute("login", loginS);
            } else {
                //redirigir a login de nuevo
                session.setAttribute("errorLogin", "Login failure, try again!");
            }
            /* Users user = usersFacade.find(loginS);
            if ((user != null) && user.getPassword().equals(passwordS)) {
            session.setAttribute("login", loginS);
            } else {
            //redirigir a login de nuevo
            session.setAttribute("errorLogin", "Login failure, try again!");
            }*/
            userPath = "/login";

        } else if (userPath.equals("/fregister")) {

            String login = request.getParameter("login");
            String pass = request.getParameter("password");
            String name = request.getParameter("nombre");
            String surname = request.getParameter("apellidos");
            String address = request.getParameter("domicilio");
            String email = request.getParameter("email");
            String phone = request.getParameter("telefono");

            //get if User exists
            Users user = usersFacade.find(login);

            if (user != null) {
                //redirigir a register de nuevo
                session.setAttribute("errorRegister", "Register failure, the login already exists!");
                userPath = "/register";
            } else {
                //addProduct
                user = new Users();
                user.setLogin(login);

                user.setPassword(usersFacade.md5(pass));

                user.setUserName(name);
                user.setSurName(surname);
                user.setAddress(address);
                user.setEmail(email);
                user.setPhone(phone);

                //update in DB
                usersFacade.create(user);
                session.setAttribute("goodRegister", "You are now registered, you can access using login!");

                //prepare message
                try {
                    Connection connection = connectionFactory.createConnection();

                    Session sessionjms = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                    MessageProducer messageProducer = sessionjms.createProducer(queue);

                    ObjectMessage message = sessionjms.createObjectMessage();
                    message.setObject(user);
                    messageProducer.send(message);
                    messageProducer.close();
                    connection.close();
                    userPath = "/login";
                } catch (JMSException ex) {
                    ex.printStackTrace();
                }
            }

        } else if (userPath.equals("/faddProducts")) {

            String type = request.getParameter("tipo");
            String kilos = request.getParameter("kilos");
            String date = request.getParameter("fecha");
            String quality = request.getParameter("calidad");
            String priceKilo = request.getParameter("precioKilo");
            String available = request.getParameter("disponible");

            //get User
            Users user = usersFacade.find(loginS);

            Products product = new Products();
            product.setTypeProduct(type);
            product.setKilos(Integer.valueOf(kilos));

            SimpleDateFormat format =
                    new SimpleDateFormat("yyyy-MM-dd");
            Date formatDate;
            try {
                formatDate = format.parse(date);
                product.setDateProduct(formatDate);
            } catch (ParseException ex) {
                Logger.getLogger(ControllerServlet.class.getName()).log(Level.SEVERE, null, ex);
            }

            product.setQuality(quality);
            product.setPriceKilo(BigDecimal.valueOf(Double.valueOf(priceKilo)));
            product.setAvailable(available);
            product.setUsers(user);

            //update in DB
            productsFacade.create(product);


            //add product to user
            user.getProductsCollection().add(product);

            //update in DB
            usersFacade.edit(user);

            //redirect
            userPath = "/manageProducts";

        } else if (userPath.equals("/delProducts")) {
            // extracting data from the checkbox field
            String[] productsID = request.getParameterValues("borrar[]");
            //output the data into a web page
            for (int i = 0; i < productsID.length; i++) {
                productsFacade.remove(productsFacade.find(Long.valueOf(productsID[i])));
            }
            userPath = "/manageProducts";
        } else if (userPath.equals("/fdelOrder")) {
            // extracting data from the checkbox field
            String[] ordersID = request.getParameterValues("borrar[]");
            //change available products and remove order
            for (int i = 0; i < ordersID.length; i++) {
                Orders o = ordersFacade.find(Long.valueOf(ordersID[i]));

                //if paid and delivered, delete products instead of reset them
                if (o.getDelivered().equals("yes") && o.getPaid().equals("yes")) {
                    for (Products p : o.getProductsCollection()) {
                        productsFacade.remove(p);
                    }
                } else {
                    for (Products p : o.getProductsCollection()) {
                        p.setAvailable("YES");
                        productsFacade.edit(p);
                    }
                }
                ordersFacade.remove(o);
            }
            userPath = "/doOrder";
        } else if (userPath.equals("/fchangeOrder")) {
            // extracting data from the checkbox field
            String[] paidID = request.getParameterValues("paid[]");
            String[] deliverID = request.getParameterValues("deliver[]");
            //change status order
            if (paidID != null) {
                for (int i = 0; i < paidID.length; i++) {
                    Orders o = ordersFacade.find(Long.valueOf(paidID[i]));
                    if (o.getPaid().equals("YES")) {
                        o.setPaid("NO");
                    } else {
                        o.setPaid("YES");
                    }
                    ordersFacade.edit(o);
                }
            }
            if (deliverID != null) {
                for (int i = 0; i < deliverID.length; i++) {
                    Orders o = ordersFacade.find(Long.valueOf(deliverID[i]));
                    if (o.getDelivered().equals("YES")) {
                        o.setDelivered("NO");
                    } else {
                        o.setDelivered("YES");
                    }
                    ordersFacade.edit(o);
                }
            }
            userPath = "/doOrder";
        } else if (userPath.equals("/fdoOrder")) {
            // extracting data from the checkbox field
            String[] productsID = request.getParameterValues("order[]");
            //output the data into a web page

            //marcarlos no disponible
            productsFacade.noDisponibles(productsID);

            //crear pedido
            Orders order = new Orders();
            order.setPaid("NO");
            order.setDelivered("NO");
            SimpleDateFormat format =
                    new SimpleDateFormat("yyyy-MM-dd");
            Date date = new Date();
            try {
                order.setDateOrder(format.parse(format.format(date)));
            } catch (ParseException ex) {
                Logger.getLogger(ControllerServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
            order.setUsers(usersFacade.find(loginS));

            //añadirlos a lista productos
            ArrayList<Products> prods = new ArrayList<Products>();
            ArrayList<String> emails = new ArrayList<String>();
            double priceFull = 0;
            for (String id : productsID) {
                Products p = productsFacade.find(Long.valueOf(id));
                priceFull += p.getKilos() * p.getPriceKilo().doubleValue();
                prods.add(p);
                if (!emails.contains(p.getUsers().getEmail())) {
                    emails.add(p.getUsers().getEmail());
                }
            }
            order.setPriceFull(BigDecimal.valueOf(priceFull));
            order.setProductsCollection(prods);

            ordersFacade.create(order);

            //marcar cada producto con su pedido
            for (Products p : prods) {
                p.setOrders(order);
                productsFacade.edit(p);
            }
            // guardar pedido y users de pedido en app
            session.setAttribute("orderPrice", order.getPriceFull());
            session.setAttribute("orderDate", order.getDateOrder());
            session.setAttribute("emails", emails);
            userPath = "/resultOrder";
        } else if (userPath.equals("/logout")) {
            session.invalidate();
            userPath = "/index";
        }
        // use RequestDispatcher to forward request internally
        String url = null;
        if (userPath.equals("/index")) {
            url = "/index.jsp";
        } else {
            url = "/WEB-INF/view" + userPath + ".jsp";
        }

        try {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
