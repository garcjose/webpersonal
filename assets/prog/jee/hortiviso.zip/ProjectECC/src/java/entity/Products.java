/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Noa
 */
@Entity
@Table(name = "products")
@NamedQueries({
    @NamedQuery(name = "Products.findAll", query = "SELECT p FROM Products p"),
    @NamedQuery(name = "Products.findByIdProduct", query = "SELECT p FROM Products p WHERE p.idProduct = :idProduct"),
    @NamedQuery(name = "Products.findByTypeProduct", query = "SELECT p FROM Products p WHERE p.typeProduct = :typeProduct"),
    @NamedQuery(name = "Products.findByKilos", query = "SELECT p FROM Products p WHERE p.kilos = :kilos"),
    @NamedQuery(name = "Products.findByPriceKilo", query = "SELECT p FROM Products p WHERE p.priceKilo = :priceKilo"),
    @NamedQuery(name = "Products.findByDateProduct", query = "SELECT p FROM Products p WHERE p.dateProduct = :dateProduct"),
    @NamedQuery(name = "Products.findByQuality", query = "SELECT p FROM Products p WHERE p.quality = :quality"),
    @NamedQuery(name = "Products.findByAvailable", query = "SELECT p FROM Products p WHERE p.available = :available")})
public class Products implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idProduct")
    private Long idProduct;
    @Basic(optional = false)
    @Column(name = "typeProduct")
    private String typeProduct;
    @Basic(optional = false)
    @Column(name = "kilos")
    private int kilos;
    @Basic(optional = false)
    @Column(name = "priceKilo")
    private BigDecimal priceKilo;
    @Basic(optional = false)
    @Column(name = "dateProduct")
    @Temporal(TemporalType.DATE)
    private Date dateProduct;
    @Basic(optional = false)
    @Column(name = "quality")
    private String quality;
    @Basic(optional = false)
    @Column(name = "available")
    private String available;
    @JoinColumn(name = "idOrder", referencedColumnName = "idOrder")
    @ManyToOne
    private Orders orders;
    @JoinColumn(name = "login", referencedColumnName = "login")
    @ManyToOne(optional = false)
    private Users users;

    public Products() {
    }

    public Products(Long idProduct) {
        this.idProduct = idProduct;
    }

    public Products(Long idProduct, String typeProduct, int kilos, BigDecimal priceKilo, Date dateProduct, String quality, String available) {
        this.idProduct = idProduct;
        this.typeProduct = typeProduct;
        this.kilos = kilos;
        this.priceKilo = priceKilo;
        this.dateProduct = dateProduct;
        this.quality = quality;
        this.available = available;
    }

    public Long getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(Long idProduct) {
        this.idProduct = idProduct;
    }

    public String getTypeProduct() {
        return typeProduct;
    }

    public void setTypeProduct(String typeProduct) {
        this.typeProduct = typeProduct;
    }

    public int getKilos() {
        return kilos;
    }

    public void setKilos(int kilos) {
        this.kilos = kilos;
    }

    public BigDecimal getPriceKilo() {
        return priceKilo;
    }

    public void setPriceKilo(BigDecimal priceKilo) {
        this.priceKilo = priceKilo;
    }

    public Date getDateProduct() {
        return dateProduct;
    }

    public void setDateProduct(Date dateProduct) {
        this.dateProduct = dateProduct;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public String getAvailable() {
        return available;
    }

    public void setAvailable(String available) {
        this.available = available;
    }

    public Orders getOrders() {
        return orders;
    }

    public void setOrders(Orders orders) {
        this.orders = orders;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idProduct != null ? idProduct.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Products)) {
            return false;
        }
        Products other = (Products) object;
        if ((this.idProduct == null && other.idProduct != null) || (this.idProduct != null && !this.idProduct.equals(other.idProduct))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Products[idProduct=" + idProduct + "]";
    }
}
